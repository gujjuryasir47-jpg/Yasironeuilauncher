package com.yasir.oneui;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final List<ResolveInfo> allApps = new ArrayList<>();
    private GridLayout appGrid;
    private EditText searchBox;
    private int ink = Color.rgb(27, 39, 58);
    private int muted = Color.rgb(104, 116, 135);
    private int surface = Color.WHITE;
    private int page = Color.rgb(241, 244, 250);

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(page);
        getWindow().setNavigationBarColor(page);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR |
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        loadApps();
        buildScreen();
        showApps("");
    }

    private void loadApps() {
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> found = pm.queryIntentActivities(query, 0);
        allApps.clear();
        for (ResolveInfo info : found) {
            if (!info.activityInfo.packageName.equals(getPackageName())) allApps.add(info);
        }
        Collections.sort(allApps, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(getPackageManager()).toString()
                        .compareToIgnoreCase(b.loadLabel(getPackageManager()).toString());
            }
        });
    }

    private void buildScreen() {
        LinearLayout base = new LinearLayout(this);
        base.setOrientation(LinearLayout.VERTICAL);
        base.setBackgroundColor(page);
        base.setPadding(dp(20), dp(18), dp(20), dp(10));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView greeting = new TextView(this);
        greeting.setText("Good day");
        greeting.setTextColor(muted);
        greeting.setTextSize(14);
        top.addView(greeting, new LinearLayout.LayoutParams(0, -2, 1));

        TextView menu = new TextView(this);
        menu.setText("⋮");
        menu.setTextSize(28);
        menu.setTextColor(ink);
        menu.setGravity(Gravity.CENTER);
        top.addView(menu, new LinearLayout.LayoutParams(dp(36), dp(36)));
        base.addView(top);

        LinearLayout clockCard = new LinearLayout(this);
        clockCard.setOrientation(LinearLayout.VERTICAL);
        clockCard.setPadding(dp(20), dp(18), dp(20), dp(18));
        clockCard.setBackground(round(Color.rgb(225, 234, 248), dp(24)));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(142));
        cp.topMargin = dp(12);
        base.addView(clockCard, cp);

        TextClock clock = new TextClock(this);
        clock.setFormat12Hour("h:mm");
        clock.setFormat24Hour("HH:mm");
        clock.setTextSize(42);
        clock.setTextColor(ink);
        clock.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        clockCard.addView(clock);

        TextClock date = new TextClock(this);
        date.setFormat12Hour("EEEE, d MMMM");
        date.setFormat24Hour("EEEE, d MMMM");
        date.setTextSize(14);
        date.setTextColor(muted);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-2, -2);
        dp.topMargin = dp(2);
        clockCard.addView(date, dp);

        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setTextSize(15);
        searchBox.setHint("Search apps");
        searchBox.setHintTextColor(muted);
        searchBox.setTextColor(ink);
        searchBox.setCompoundDrawablePadding(dp(10));
        searchBox.setPadding(dp(16), 0, dp(16), 0);
        searchBox.setBackground(round(surface, dp(18)));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(52));
        sp.topMargin = dp(18);
        base.addView(searchBox, sp);

        TextView heading = new TextView(this);
        heading.setText("Apps");
        heading.setTextColor(ink);
        heading.setTextSize(20);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(20);
        hp.bottomMargin = dp(10);
        base.addView(heading, hp);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        appGrid = new GridLayout(this);
        appGrid.setColumnCount(4);
        appGrid.setUseDefaultMargins(false);
        scroll.addView(appGrid, new ScrollView.LayoutParams(-1, -2));
        base.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = new TextView(this);
        footer.setText("YASIR  •  ONE UI INSPIRED");
        footer.setTextColor(muted);
        footer.setTextSize(10);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(8), 0, dp(4));
        base.addView(footer);

        setContentView(base);

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                showApps(s.toString());
            }
            @Override public void afterTextChanged(Editable e) {}
        });
    }

    private void showApps(String filter) {
        if (appGrid == null) return;
        appGrid.removeAllViews();
        String key = filter.toLowerCase(Locale.getDefault()).trim();
        int count = 0;
        for (final ResolveInfo info : allApps) {
            final String label = info.loadLabel(getPackageManager()).toString();
            if (!label.toLowerCase(Locale.getDefault()).contains(key)) continue;

            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(3), dp(9), dp(3), dp(9));
            item.setBackground(makeRipple());

            ImageView icon = new ImageView(this);
            try { icon.setImageDrawable(info.loadIcon(getPackageManager())); }
            catch (Exception ignored) {}
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(48), dp(48));
            item.addView(icon, ip);

            TextView name = new TextView(this);
            name.setText(label);
            name.setTextColor(ink);
            name.setTextSize(11);
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(1);
            name.setPadding(0, dp(6), 0, 0);
            item.addView(name, new LinearLayout.LayoutParams(-1, -2));

            item.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Intent launch = new Intent(Intent.ACTION_MAIN);
                    launch.addCategory(Intent.CATEGORY_LAUNCHER);
                    launch.setClassName(info.activityInfo.packageName, info.activityInfo.name);
                    try { startActivity(launch); } catch (Exception ignored) {}
                }
            });

            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = 0;
            params.height = dp(94);
            params.columnSpec = GridLayout.spec(count % 4, 1f);
            params.rowSpec = GridLayout.spec(count / 4);
            appGrid.addView(item, params);
            count++;
        }
        if (count == 0) {
            TextView empty = new TextView(this);
            empty.setText("No apps found");
            empty.setTextColor(muted);
            empty.setPadding(dp(8), dp(18), dp(8), dp(18));
            appGrid.addView(empty);
        }
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private android.graphics.drawable.Drawable makeRipple() {
        GradientDrawable mask = round(Color.WHITE, dp(18));
        return new android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(Color.rgb(220, 228, 240)),
                null, mask);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
