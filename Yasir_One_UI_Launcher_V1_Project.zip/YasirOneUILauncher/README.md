# Yasir One UI Launcher (V1)

A lightweight Android home-screen launcher prototype for Redmi 9A / Android 10.

## Requirements
- Android 10 or newer on the phone (minSdk 29)
- Android SDK Platform 35
- JDK 17
- Android Gradle Plugin 8.6.1 / Gradle 8.7

## Build
1. Open this folder as an Android project in an Android IDE that supports Gradle projects.
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Build > Build APK(s).
4. Install the generated APK on the Redmi 9A.
5. Press Home and choose **Yasir One UI Launcher**. You can also select it in Settings > Apps > Default apps > Home app.

## Current V1 features
- Home-screen style clock/date card
- Searchable grid of installed launchable apps
- Opens selected apps
- Rounded One UI-inspired surfaces
- No root required and no extra runtime permissions

## Notes
- This is an original One UI-inspired launcher, not Samsung software.
- A normal launcher cannot replace MIUI's system Settings, lock screen, or notification shade.
- This first version intentionally avoids heavy animations and external libraries for low-memory devices.
